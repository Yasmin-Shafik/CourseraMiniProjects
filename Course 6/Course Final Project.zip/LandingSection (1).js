import React from "react";
import { Avatar, color, Heading, VStack } from "@chakra-ui/react";
import FullScreenSection from "./FullScreenSection";

const greeting = "Hi all, I am Yasmin!";
const bio1 = "I work as a Software Engineer";
const bio2 = "Utilziing React in Front-End Development";


// Implement the UI for the LandingSection component according to the instructions.
// Use a combination of Avatar, Heading and VStack components.
const LandingSection = () => (
  <FullScreenSection
    justifyContent="center"
    alignItems="center"
    isDarkBackground
    backgroundColor="pink"
  >
    <VStack
      spacing={5}
    >
      <Avatar name="Yasmin" src="https://i.pravatar.cc/150?img=7" size="xl" backgroundColor="black"/>
      <Heading as="h1" size="md" color="white">
        {greeting}
      </Heading>
      <p style={{ fontSize: '2em' }} >{bio1}<br/>{bio2}</p>
    </VStack>
  </FullScreenSection>
);

export default LandingSection;
